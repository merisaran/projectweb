<h1>Daftar Rumah baru</h1>

<form action="daftar-simpan.php" method="post">
    <table>
        <tr>
            <td>Jumlah Bilik</td>
            <td><input type="text" name="jumlahBilik"></td>
        </tr>
        <tr>
            <td>Model</td>
            <td><input type="text" name="model"></td>
        </tr>
          <tr>
            <td>Harga</td>
            <td><input type="text" name="harga"></td>
        </tr>
        <tr>
            <td><button type="submit">Simpan</button></td>
        </tr>
    </table>
</form>