<?php

$server = 'localhost';
$username = 'root';
$password = '';
$dbname = 'srs';
$conn = new mysqli($server, $username, $password, $dbname);

session_start();

