<h1>Tukar Kata Laluan</h1>

<form action="katalaluan-tukar.php" method="post">
    <table>
        <tr>
            <td>Kata laluan asal</td>
            <td><input type="password" name="kata1" required></td>
        </tr>
        <tr>
            <td>Kata laluan baru</td>
            <td><input type="password" name="kata2" required></td>
        </tr>
        <tr>
            <td>Ulang kata laluan baru</td>
            <td><input type="password" name="kata3" required></td>
        </tr>
        <tr>
            <td>
                <button type="submit">Tukar</button>
            </td>
        </tr>
    </table>
</form>