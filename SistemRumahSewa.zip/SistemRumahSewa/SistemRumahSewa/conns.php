<?php

$server = 'localhost';
$username = 'id16900411_admin';
$password = '$in3mQazYktwEqv1';
$dbname = 'id16900411_srs';
$conn = new mysqli($server, $username, $password, $dbname);

session_start();
